using System;
using Soccer.Application.Models;
using Soccer.Domain;

namespace Soccer.Application.Mappers
{
    public class GameToGameReportMapper
    {
        public GameReport Map(Game game)
        { 
            throw new NotImplementedException("Es necesario implementar un conversor entre objetos Game y GameReport");
        }
    }
}