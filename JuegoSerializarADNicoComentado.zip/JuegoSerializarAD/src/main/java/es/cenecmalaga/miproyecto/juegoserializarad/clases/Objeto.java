/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.cenecmalaga.miproyecto.juegoserializarad.clases;

/**
 *
 * @author mparamos
 */
public class Objeto extends ElementoConFuerza{

    public Objeto(String nombre, byte fuerza) {
        super(nombre, fuerza);
    }
    
}
