using Soccer.Application.Models;
using Soccer.Domain;
using System;

namespace Soccer.Application.Mappers
{
    public class GameToGameReportMapper
    {
        public GameReport Map(Game game)//Funcion q recibe por patametros un game y devuelve un GameReport
        {     
         GameReport informe = new GameReport(game.Id,game.LocalTeamCode,game.LocalGoals.Count,game.ForeignTeamCode,game.ForeignGoals.Count);
            return informe;
        }
    }
}