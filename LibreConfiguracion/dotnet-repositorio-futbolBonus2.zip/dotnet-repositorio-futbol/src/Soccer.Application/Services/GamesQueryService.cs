using Soccer.Application.Mappers;
using Soccer.Application.Models;
using System;

namespace Soccer.Application.Services
{
    public class GamesQueryService
    {
        private readonly IGamesRepository _gamesRepository;//representa al repositorio, donde se almacena los datos
        private readonly GameToGameReportMapper _gameToGameReportMapper;//te permite convertir  de la clase game a gamereport

        public GamesQueryService(IGamesRepository gamesRepository,GameToGameReportMapper gameToGameReportMapper)
        {
            _gamesRepository = gamesRepository;
            _gameToGameReportMapper = gameToGameReportMapper;
        }

        public GameReport GetGameReport(Guid id)
        {
            var game = _gamesRepository.GetGame(id);
            var gameReport = _gameToGameReportMapper.Map(game);
            return gameReport;
        }
    }
}