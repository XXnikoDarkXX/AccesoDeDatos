﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Soccer.Application.Exceptions
{
    public class IdYaExisteException : Exception
    {
        public IdYaExisteException(String message) : base(message)
        {

        }
    }
}
