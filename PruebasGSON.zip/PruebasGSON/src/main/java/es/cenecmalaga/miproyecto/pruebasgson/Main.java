/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.cenecmalaga.miproyecto.pruebasgson;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import unmarshalling.Biblioteca;

/**
 *
 * @author mparamos
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        FileWriter fichero=null;
        try {
            
            
            GsonBuilder builder=new GsonBuilder();
            builder.setPrettyPrinting();
            builder.setDateFormat("Y/M/d");
            Gson gson=builder.create();
            
            ArrayList<Persona> personas=new ArrayList<Persona>();
            for (int i = 0; i < 50; i++) {
                personas.add(new Persona());
            }
            
            String personaJson=gson.toJson(personas);
            System.out.println(personaJson);
            fichero = new FileWriter("./salida.json");
            fichero.write(personaJson);
            fichero.flush();
            
            try{
                FileReader fr=new FileReader("./videojuegos.json");
                Biblioteca biblio=(Biblioteca)gson.fromJson(fr,Biblioteca.class);
                System.out.println(biblio);
            }catch(JsonSyntaxException jse){
                System.out.println("El fichero JSON no tiene el formato esperado");
            }
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fichero.close();
            } catch (IOException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
}
