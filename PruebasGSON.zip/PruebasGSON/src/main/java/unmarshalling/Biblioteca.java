/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unmarshalling;

import java.util.ArrayList;

/**
 *
 * @author mparamos
 */
public class Biblioteca {
    private String bibliotecaDe;
    private ArrayList<Juego> juegos;

    public Biblioteca(String bibliotecaDe, ArrayList<Juego> juegos) {
        this.bibliotecaDe = bibliotecaDe;
        this.juegos = juegos;
    }

    public String getBibliotecaDe() {
        return bibliotecaDe;
    }

    public void setBibliotecaDe(String bibliotecaDe) {
        this.bibliotecaDe = bibliotecaDe;
    }

    public ArrayList<Juego> getJuegos() {
        return juegos;
    }

    public void setJuegos(ArrayList<Juego> juegos) {
        this.juegos = juegos;
    }

    @Override
    public String toString() {
        return "Biblioteca{" + "bibliotecaDe=" + bibliotecaDe + ", juegos=" + juegos + '}';
    }
    
    
}
