/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.cenecmalaga.miproyecto.pruebasgson;

import java.sql.Date;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Random;
import java.util.TreeMap;

/**
 *
 * @author mparamos
 */
public class Persona {
    private String nombre;
    private short anioNacimiento;
    private char genero;
    private String dni;
    private HashSet<Asignaturas> convalidaciones;
    final private LocalDateTime fechaRegistro;
    final private Date fechaFalsa;
    private TreeMap<Asignaturas,Float> asignaturas;
    
    public enum Asignaturas{
        PMDM,
        AD,
        PSP,
        EIE,
        DI,
        SGE
    }
    
    public Persona(){
        fechaRegistro=LocalDateTime.now();
        fechaFalsa=Date.valueOf(fechaRegistro.toLocalDate());
        String[] nombresHombre={"Raúl","Antonio","Francisco","Álvaro","Manuel","Alberto","Nico","Juanlu","Javier","Daniel","Norberto","Alex"};
        String[] nombresMujer={"María","Cristina","Yuliia","Ana","Marta","Sandra","Laura","Esther","Isabel","Rocío","Carla","Noelia","Raquel"};
        Random r=new Random();
        if(r.nextBoolean()){
            genero='h';
            nombre=nombresHombre[r.nextInt(nombresHombre.length)];
        }else{
            genero='m';
            nombre=nombresMujer[r.nextInt(nombresMujer.length)];
        }
        anioNacimiento=(short)(r.nextInt(80)+1940);
        dni="";
        for (int i = 0; i < 8; i++) {
            dni+=r.nextInt(10);
        }
        dni+=(char)(r.nextInt(25)+65);
        asignaturas=new TreeMap<Asignaturas,Float>();
        asignaturas.put(Asignaturas.PMDM,(float)r.nextInt(11));
        asignaturas.put(Asignaturas.AD,(float)r.nextInt(11));
        asignaturas.put(Asignaturas.PSP,(float)r.nextInt(11));
        asignaturas.put(Asignaturas.SGE,(float)r.nextInt(11));
        //asignaturas.put(Asignaturas.EIE,(float)r.nextInt(11));
        //asignaturas.put(Asignaturas.DI,(float)r.nextInt(11));
        convalidaciones=new HashSet<Asignaturas>();
        convalidaciones.add(Asignaturas.EIE);
        convalidaciones.add(Asignaturas.DI);
    }

    public Persona(String nombre, short anioNacimiento, char genero, String dni) {
        this.nombre = nombre;
        this.anioNacimiento = anioNacimiento;
        this.genero = genero;
        this.dni = dni;
        fechaRegistro=LocalDateTime.now();
        fechaFalsa=Date.valueOf(fechaRegistro.toLocalDate());
        asignaturas=new TreeMap<Asignaturas,Float>();
        convalidaciones=new HashSet<Asignaturas>();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public short getAnioNacimiento() {
        return anioNacimiento;
    }

    public void setAnioNacimiento(short anioNacimiento) {
        this.anioNacimiento = anioNacimiento;
    }

    public char getGenero() {
        return genero;
    }

    public void setGenero(char genero) {
        this.genero = genero;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }
    
    
    
}
