using FluentAssertions;
using Soccer.IntegrationTests.TestSupport;
using Soccer.IntegrationTests.TestSupport.Builders;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Xunit;

namespace Soccer.IntegrationTests.UseCases.AddGame
{
    public static class AddGameTests
    {
        public class Given_A_NewGame_When_Posting : FunctionalTest
        {
            private string _url;//direccion
            private HttpResponseMessage _result;//respuesta
            private StringContent _content;//contenido

            protected override Task Given()
            {
                _url = "games";//cargamos en url "games"
                var jsonStream = new FileStreamBuilder()//guardamos en una variable el FileStreamBuilder
                        .WithFileResourceName("add_game_new_game.json")
                        .Build();
                _content = new StringContentBuilder()//cargamos la variable jsonStream en  _content 
                        .WithContent(jsonStream)
                        .Build();

                return Task.CompletedTask;//devuelve tarea completada
            }

            protected override async Task When()
            {
                _result = await HttpClient.PostAsync(_url, _content);//cargamos en _result, la url y content
            }

            [Fact]
            public void Then_It_Should_Return_201_Created()
            {
                _result.StatusCode.Should().Be(HttpStatusCode.Created);//comprobacion de Status de _result 
            }

            [Fact]
            public void Then_It_Should_Return_A_Location_Header()
            {
                _result.Headers.Location.Should().NotBeNull();
            }
        }
    }
}