module CornavirusRandomAcces {
}