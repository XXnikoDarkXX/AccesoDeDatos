# dotnet-repositorio

Ejemplo de patrón repositorio con .NET 5 y C# como base para temas de adaptación de impedancias objeto-relacionales, ORM y modelos anémicos.