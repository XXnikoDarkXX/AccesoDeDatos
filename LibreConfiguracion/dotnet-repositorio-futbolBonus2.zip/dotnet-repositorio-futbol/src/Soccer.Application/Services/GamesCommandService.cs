using Soccer.Application.Exceptions;
using Soccer.Application.Mappers;
using Soccer.Application.Models;
using Soccer.Domain;
using System;
using System.Collections.Generic;

namespace Soccer.Application.Services
{
    public class GamesCommandService
    {
        private readonly IGamesRepository _gamesRepository;//extiende de la interfaz IGamesRepository
        private readonly IDateTimeService _dateTimeService;//fechas

        public GamesCommandService(
            IGamesRepository gamesRepository,
            IDateTimeService dateTimeService)
        {
            _gamesRepository = gamesRepository;
            _dateTimeService = dateTimeService;
        }

        public Guid CreateGame(NewGame newGame)
        {
            var newId = Guid.NewGuid();
            var game = new Game(newId);

            game.AddLocalTeam(newGame.LocalTeamCode);
            game.AddForeignTeam(newGame.ForeignTeamCode);

            _gamesRepository.AddGame(game);

            return newId;
        }

        public void SetProgress(Guid id, GameProgress gameProgress)
        {
            var game = _gamesRepository.GetGame(id);
            var currentDate = _dateTimeService.GetUtcNow();
            if (gameProgress.IsInProgress)
            {
                game.Start(currentDate);
            }
            else
            {
                game.End(currentDate);
            }

            _gamesRepository.UpdateGame(id, game);
        }

        public void AddGoal(Guid id, NewGoal newGoal)
        {
            var game = _gamesRepository.GetGame(id);
            var currentDate = _dateTimeService.GetUtcNow();
            var teamCode = newGoal.TeamCode;
            var goal = new Goal(currentDate, newGoal.ScoredBy);
            var isTeamPlaying = game.LocalTeamCode == teamCode || game.ForeignTeamCode == teamCode;
            if (!isTeamPlaying)
            {
                throw new ResourceNotFoundException($"The team code {teamCode} is not playing the game");
            }

            if (game.LocalTeamCode == teamCode)
            {
                game.AddLocalTeamGoal(goal);
            }
            else
            {
                game.AddForeignTeamGoal(goal);
            }

            _gamesRepository.UpdateGame(id, game);
        }

        //Metodo que devuelve una lista con los reports de la BBDD
        public List<GameReport> AllReport()
        {
            List<Game> lista = new List<Game>();
            lista = (List<Game>)_gamesRepository.GetGames();

            List<GameReport> ListaReportes = new List<GameReport>();
            GameToGameReportMapper mapeador = new GameToGameReportMapper();

            for (int i = 0; i < lista.Count; i++)//iteramos mapeando
            {
                ListaReportes.Add(mapeador.Map(lista[i]));
            }

            return ListaReportes;
        }

        
        public void DeleteGame(Guid id)
        {
            _gamesRepository.RemoveGame(id);
        }
    }
}