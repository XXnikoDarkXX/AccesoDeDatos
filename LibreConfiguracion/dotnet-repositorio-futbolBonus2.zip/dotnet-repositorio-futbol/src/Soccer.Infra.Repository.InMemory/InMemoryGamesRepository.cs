﻿using Soccer.Application;
using Soccer.Domain;
using System;
using System.Collections.Generic;

namespace Soccer.Infra.Repository.InMemory
{
    public class InMemoryGamesRepository : IGamesRepository
    {
        private readonly Dictionary<Guid, Game> baseDatos;

        public InMemoryGamesRepository()
        {
            baseDatos = new Dictionary<Guid, Game>();
        }

        public IEnumerable<Game> GetGames()
        {
            List<Game> lista = new List<Game>();
            foreach(KeyValuePair<Guid, Game> entry in baseDatos)
            {
                lista.Add(entry.Value);
            }
            return lista;
        }

        public Game GetGame(Guid id)
        {
            return baseDatos[id];
        }

        public void RemoveGame(Guid id)
        {
            baseDatos.Remove(id);
        }

        public void UpdateGame(Guid id, Game game)
        {
    
           baseDatos[id] = game;//actualizar el valor a traves de la clave
     
        }

        public void AddGame(Game game)//funcion para ñadir juego a la bd
        {
            if(baseDatos.ContainsKey(game.Id))
            {
                throw new Application.Exceptions.IdYaExisteException("La id ya existe");
            }
            else
            {
                baseDatos.Add(game.Id, game);
            }
        }
    }
}